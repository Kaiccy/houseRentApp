//
//  Helper.m
//  EHouse
//
//  Created by wx on 2016/12/16.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "Helper.h"

@implementation Helper

+ (instancetype)shareHelper{
    
    static Helper *helper = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        helper = [[Helper alloc] init];
    });
    
    return helper;
}


@end
