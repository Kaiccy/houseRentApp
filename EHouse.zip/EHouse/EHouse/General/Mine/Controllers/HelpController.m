//
//  HelpController.m
//  EHouse
//
//  Created by wx on 2016/12/19.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "HelpController.h"

@interface HelpController ()

@end

@implementation HelpController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    kSetNavigationBar(@"帮助")
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self addViews];
}

//添加View
- (void)addViews{
    
    //提示label
    UILabel *tipLabel = [[UILabel alloc] init];
    [self.view addSubview:tipLabel];
    tipLabel.textColor = kWordColor(102, 102, 102);
    tipLabel.text = @"如有疑问请联系客服";
    tipLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:17];
    [tipLabel makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(15);
        make.top.equalTo(35 * kPercent + 64);
    }];
    
    // 图标
    UIButton *iconBtn = [UIButton buttonWithType:(UIButtonTypeSystem)];
    [self.view addSubview:iconBtn];
    [iconBtn setImage:[UIImage imageNamed:@"service"] forState:(UIControlStateNormal)];
    iconBtn.imageView.contentMode = UIViewContentModeCenter;
    [iconBtn makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(tipLabel.bottom).equalTo(15);
        make.left.equalTo(15);
        make.width.equalTo(20);
        make.height.equalTo(20);
    }];
    [iconBtn addTarget:self action:@selector(callService:) forControlEvents:(UIControlEventTouchUpInside)];
    
    //电话号码
    UILabel *phoneNumL = [[UILabel alloc] init];
    phoneNumL.text = @"0571-87783552";
    [self.view addSubview:phoneNumL];
    [phoneNumL makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(iconBtn.right).equalTo(10);
        make.centerY.equalTo(iconBtn);
    }];
    
}

//拨打电话
- (void)callService:(UIButton *)button{
    
    NSLog(@"拨打电话");
    NSString *phoneNumber = @"0571-87783552";
    UIWebView*callWebview =[[UIWebView alloc] init];
    
    NSURL *telURL =[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",phoneNumber]];
    [callWebview loadRequest:[NSURLRequest requestWithURL:telURL]];
    //记得添加到view上
    [self.view addSubview:callWebview];
}

//返回
- (void)back{
    
    [self.navigationController popViewControllerAnimated:YES];
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
