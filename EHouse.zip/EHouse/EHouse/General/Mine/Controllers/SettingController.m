//
//  SettingController.m
//  EHouse
//
//  Created by wx on 2016/12/19.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "SettingController.h"

@interface SettingController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) NSArray *titleArr;
@property (nonatomic, strong) UITableView *tableView;

@end

@implementation SettingController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    kSetNavigationBar(@"设置")
    
    [self addViews];
    
    //注册cell
    [self.tableView registerNib:[UINib nibWithNibName:@"InfoCell" bundle:nil] forCellReuseIdentifier:@"InfoCell"];
    
}

//添加views
- (void)addViews{
    
    self.titleArr = [NSArray arrayWithObjects:@"密码重置",@"清除缓存", nil];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    //退出按钮
    UIButton *quitBtn = [UIButton buttonWithType:(UIButtonTypeSystem)];
    [self.view addSubview:quitBtn];
    quitBtn.backgroundColor = kWordColor(5, 180, 255);
    [quitBtn setTitle:@"退    出" forState:(UIControlStateNormal)];
    quitBtn.titleLabel.font = [UIFont systemFontOfSize:17];
    quitBtn.tintColor = [UIColor whiteColor];
    [quitBtn addTarget:self action:@selector(quitLogin:) forControlEvents:(UIControlEventTouchUpInside)];
    [quitBtn makeConstraints:^(MASConstraintMaker *make) {
        
        make.bottom.equalTo(-55 * kPercent);
        make.width.equalTo(280 * kPercent);
        make.height.equalTo(44 * kPercent);
        make.centerX.equalTo(self.view);
    }];
    
    //tableView
    self.tableView = [[UITableView alloc] init];
    [self.view addSubview:_tableView];
    [self.tableView makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(64);
        make.left.right.equalTo(self.view);
        make.bottom.equalTo(quitBtn.top).equalTo(-20);
    }];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    InfoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"InfoCell"];
    
    cell.textF.hidden = YES;
    cell.title = _titleArr[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return  cell;
}


//退出登录
- (void)quitLogin:(UIButton *)button{
    
    
}

//返回
- (void)back{
    
    [self.navigationController popViewControllerAnimated:YES];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
