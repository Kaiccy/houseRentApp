//
//  AboutCompanyController.m
//  EHouse
//
//  Created by wx on 2016/12/20.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "AboutCompanyController.h"

@interface AboutCompanyController ()

@end

@implementation AboutCompanyController

- (void)viewDidLoad {
    [super viewDidLoad];

    kSetNavigationBar(@"关于公司")
    
}

- (void)back{
    
    [self.navigationController popViewControllerAnimated:YES];
}











- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
