//
//  ApproveController.m
//  EHouse
//
//  Created by wx on 2016/12/20.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "ApproveController.h"

@interface ApproveController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSArray *titleArr;
@property (nonatomic, strong) NSArray *imgArr;
@property (nonatomic, strong) NSArray *placeholderArr;

@end

@implementation ApproveController

- (void)viewDidLoad {
    [super viewDidLoad];

    kSetNavigationBar(@"租客认证")
    [self addViews];
    
    //注册cell
    [self.tableView registerNib:[UINib nibWithNibName:@"IconTextCell" bundle:nil] forCellReuseIdentifier:@"IconTextCell"];
    
    self.titleArr = [NSArray arrayWithObjects:@"绑定手机号",@"姓名",@"身份证号码",@"物业地址", nil];
    self.imgArr = [NSArray arrayWithObjects:@"phone",@"name",@"",@"tenementAddress", nil];
    self.placeholderArr = [NSArray arrayWithObjects:@"请输入手机号",@"请输入姓名",@"请输入身份证号码",@"请在这里输入地址", nil];
}

//添加view
- (void)addViews{
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"提交" style:UIBarButtonItemStylePlain target:self action:@selector(submit)];
    //修改item字体大小以及颜色
    self.navigationItem.rightBarButtonItem.tintColor = [UIColor blackColor];
    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:14], NSFontAttributeName, [UIColor blackColor], NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    
    self.view.backgroundColor = kBackgroudColor;
    
    self.tableView = [[UITableView alloc] init];
    [self.view addSubview:_tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.left.right.equalTo(0);
        make.height.equalTo(285 * kPercent);
    }];

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    IconTextCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IconTextCell"];
    
    cell.iconV.image = [UIImage imageNamed:_imgArr[indexPath.row]];
    cell.title = _titleArr[indexPath.row];
    cell.textF.placeholder = _placeholderArr[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

//返回
- (void)back{
    
    [self.navigationController popViewControllerAnimated:YES];
}

//提交认证
- (void)submit{
    
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
