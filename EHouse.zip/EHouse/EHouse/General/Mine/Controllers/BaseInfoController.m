//
//  BaseInfoController.m
//  EHouse
//
//  Created by wx on 2016/12/16.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "BaseInfoController.h"

@interface BaseInfoController ()

@property (nonatomic, strong) NSArray *titleArr;
@property (nonatomic, strong) NSArray *textArr;

@end

@implementation BaseInfoController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    kSetNavigationBar(@"个人信息")
    
    //保存按钮
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"保存" style:(UIBarButtonItemStylePlain) target:self action:@selector(saveBaseInfoAction)];
//    self.navigationItem.rightBarButtonItem.tintColor = kBlueColor;
    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:14], NSFontAttributeName, kBlueColor, NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    
    self.titleArr = [NSArray arrayWithObjects:@"昵称",@"性别",@"生日",@"手机", nil];
    self.textArr = [NSArray arrayWithObjects:@"予痛苦以希望",@"男",@"1997-08-15",@"13267896543", nil];
    
    //注册cell HeadIconCell
    [self.tableView registerNib:[UINib nibWithNibName:@"InfoCell" bundle:nil] forCellReuseIdentifier:@"InfoCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"HeadIconCell" bundle:nil] forCellReuseIdentifier:@"HeadIconCell"];
    
    //去分割线
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;

}

- (void)back{
    
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == 0) {
        HeadIconCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HeadIconCell"];
            
        UILabel *line2 = [[UILabel alloc] init];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    
    InfoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"InfoCell"];
    
    if (indexPath.row == 4) {
        cell.lineL.backgroundColor = [UIColor blackColor];
        
    }
    cell.title = _titleArr[indexPath.row - 1];
    cell.textF.text = _textArr[indexPath.row - 1];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        return 95 * kPercent;
    }
    return 56 * kPercent;
}

#pragma 保存基本信息
- (void)saveBaseInfoAction{
    
    NSLog(@"保存信息");
    LoginController *loginVC = [[LoginController alloc] init];
    [self presentViewController:loginVC animated:YES completion:nil];
}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
