//
//  MineViewController.m
//  E_House
//
//  Created by wx on 2016/12/13.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "MineViewController.h"
#import "BaseInfoController.h"
#import "SettingController.h"
#import "HelpController.h"
#import "PayController.h"
#import "ApproveController.h"
#import "AboutCompanyController.h"

@interface MineViewController ()

@property (nonatomic, strong) NSArray *titleArr;
@property (nonatomic, strong) NSArray *imgArr;

@property (weak, nonatomic) IBOutlet UIImageView *headerIconV;

@end

@implementation MineViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self setViewStyle];

}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
}

- (void)setViewStyle{
    
    self.titleArr = [NSArray arrayWithObjects:@"租客认证",@"租金支付",@"帮助",@"关于公司", nil];
    self.imgArr = [NSArray arrayWithObjects:@"approve",@"pay",@"help",@"about", nil];
    
    //去分割线
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    //头像切圆
    _headerIconV.layer.masksToBounds = YES;
    _headerIconV.layer.cornerRadius = _headerIconV.bounds.size.height / 2;
    
    //添加手势
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toBaseInfoVC)];
    [self.headerIconV addGestureRecognizer:tap];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MineCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MineCell"];
    
    if (indexPath.row == 0) {
        cell.lineL.hidden = YES;
    }
    cell.title = _titleArr[indexPath.row];
    cell.imgStr = _imgArr[indexPath.row];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 56.5 * kPercent;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //租客认证 ApproveController.h
    if (indexPath.row == 0) {
        ApproveController *approveVC = [[ApproveController alloc] init];
        approveVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:approveVC animated:YES];
    }

    //租金支付
    if (indexPath.row == 1) {
        PayController *payVC = [[PayController alloc] init];
        payVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:payVC animated:YES];
    }
    
    //帮助
    if (indexPath.row == 2) {
        HelpController *helpVC = [[HelpController alloc] init];
        helpVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:helpVC animated:YES];
    }
    
    //关于公司
    if (indexPath.row == 3) {
        AboutCompanyController *aboutCompanyVC = [[AboutCompanyController alloc] init];
        aboutCompanyVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:aboutCompanyVC animated:YES];
    }
    
}

//跳转至设置页面
- (IBAction)toSettingViewController:(UIBarButtonItem *)sender {
    
    SettingController *settingVC = [[SettingController alloc] init];
    settingVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:settingVC animated:YES];
}

//跳转至基本信息页面
- (void)toBaseInfoVC{
    
    BaseInfoController *baseinfoVC = [[BaseInfoController alloc] init];
    baseinfoVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:baseinfoVC animated:YES];
    
}




















- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
