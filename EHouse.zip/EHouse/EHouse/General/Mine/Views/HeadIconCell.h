//
//  HeadIconCell.h
//  EHouse
//
//  Created by wx on 2016/12/16.
//  Copyright © 2016年 wx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeadIconCell : UITableViewCell

@end
