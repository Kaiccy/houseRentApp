//
//  InfoCell.m
//  EHouse
//
//  Created by wx on 2016/12/16.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "InfoCell.h"

@interface InfoCell ()

@property (weak, nonatomic) IBOutlet UILabel *titleL;


@end

@implementation InfoCell

- (void)awakeFromNib {
    [super awakeFromNib];

}


- (void)setTitle:(NSString *)title{
    
    _titleL.text = title;
}








- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
