//
//  InfoCell.h
//  EHouse
//
//  Created by wx on 2016/12/16.
//  Copyright © 2016年 wx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoCell : UITableViewCell

@property (strong, nonatomic) NSString *title;

@property (weak, nonatomic) IBOutlet UILabel *lineL;
@property (weak, nonatomic) IBOutlet UITextField *textF;


@end
