//
//  HeadIconCell.m
//  EHouse
//
//  Created by wx on 2016/12/16.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "HeadIconCell.h"

@interface HeadIconCell ()

@property (weak, nonatomic) IBOutlet UIImageView *headerIconV;


@end

@implementation HeadIconCell

- (void)awakeFromNib {
    [super awakeFromNib];

    _headerIconV.layer.masksToBounds = YES;
    _headerIconV.layer.cornerRadius = _headerIconV.bounds.size.width / 2;
}














- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
