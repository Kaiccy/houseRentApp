//
//  MineCell.h
//  EHouse
//
//  Created by wx on 2016/12/15.
//  Copyright © 2016年 wx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MineCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lineL;

@property (strong, nonatomic) NSString *title;

@property (strong, nonatomic) NSString *imgStr;

@end
