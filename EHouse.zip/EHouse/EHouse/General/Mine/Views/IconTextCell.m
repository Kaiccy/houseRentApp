//
//  IconTextCell.m
//  EHouse
//
//  Created by wx on 2016/12/20.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "IconTextCell.h"

@interface IconTextCell ()

@property (weak, nonatomic) IBOutlet UILabel *titleL;

@end

@implementation IconTextCell

- (void)awakeFromNib {
    [super awakeFromNib];


}

- (void)setTitle:(NSString *)title{
    
    self.titleL.text = title;
}










- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
