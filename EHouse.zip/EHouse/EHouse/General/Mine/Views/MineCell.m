//
//  MineCell.m
//  EHouse
//
//  Created by wx on 2016/12/15.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "MineCell.h"

@interface MineCell ()

@property (weak, nonatomic) IBOutlet UILabel *titleL;

@property (weak, nonatomic) IBOutlet UIImageView *imgV;

@end

@implementation MineCell

- (void)awakeFromNib {
    [super awakeFromNib];

    
    
    
}

- (void)setTitle:(NSString *)title{
    
    _titleL.text = title;
}

- (void)setImgStr:(NSString *)imgStr{
    
    _imgV.image = [UIImage imageNamed:imgStr];
}



















- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
