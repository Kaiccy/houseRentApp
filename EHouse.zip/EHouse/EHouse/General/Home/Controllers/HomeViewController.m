//
//  HomeViewController.m
//  E_House
//
//  Created by wx on 2016/12/13.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "HomeViewController.h"
#import "MapCell.h"

#import "WXTool.h"

@interface HomeViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UIButton * locationBtn;
@property (nonatomic, strong) UITableView *tableView;

//图片数组
@property (nonatomic, strong) NSArray *bannerImgArr;

@end

@implementation HomeViewController

- (void)viewWillAppear:(BOOL)animated{
    
    self.navigationController.navigationBar.translucent = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.bannerImgArr = [NSArray arrayWithObjects:@"banner",@"banner",@"banner", nil];

    [self setViews];
    
    
//    NSDictionary *params = @{
//                             @"username":@"xujian",
//                             @"password":@"xujian"
//                             };
//    [WXTool wx_POST:@"http://www.eju-house.com/ej.admin.com/EJLogin.php" params:params success:^(id responseObject) {
//        
//        NSLog(@"------%@",responseObject);
//        
//    } failure:^(NSError *error) {
//        
//        NSLog(@"请求失败");
//    }];

}

- (void)setViews{
    
    self.view.backgroundColor = kBackgroudColor;
    
    //设置左边的item
    self.locationBtn = [UIButton buttonWithType:(UIButtonTypeSystem)];
    _locationBtn.frame = CGRectMake(0, 0, 50, 40);
    _locationBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    _locationBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -5, 0, 0);
    [_locationBtn setTitle:@"杭州" forState:UIControlStateNormal];
    [_locationBtn setImage:[UIImage imageNamed:@"location"] forState:UIControlStateNormal];
    [_locationBtn setTintColor:[UIColor blackColor]];
    [_locationBtn addTarget:self action:@selector(locationAction) forControlEvents:(UIControlEventTouchUpInside)];
    UIBarButtonItem * loactionItem = [[UIBarButtonItem alloc] initWithCustomView:_locationBtn];
    self.navigationItem.leftBarButtonItem = loactionItem;
    
    //tableView
    self.tableView = [[UITableView alloc] init];
    [self.view addSubview:_tableView];
    [_tableView makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.left.right.bottom.equalTo(self.view);
    }];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    //注册cell
    [self.tableView registerNib:[UINib nibWithNibName:@"TriImgTextCell" bundle:nil] forCellReuseIdentifier:@"TriImgTextCell"];
    [self.tableView  registerNib:[UINib nibWithNibName:@"ImgTextCell" bundle:nil] forCellReuseIdentifier:@"ImgTextCell"];
    [self.tableView  registerNib:[UINib nibWithNibName:@"MapCell" bundle:nil] forCellReuseIdentifier:@"MapCell"];
    
    //header 轮播图
    _tableView.tableHeaderView = ({
        // 网络加载图片的轮播器
        
        SDCycleScrollView *cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 69, ScreenWidth - 10, 190 * kPercent) imageURLStringsGroup:_bannerImgArr];
        //当前点的图
        cycleScrollView.currentPageDotImage = [UIImage imageNamed:@"01"];
        //其他的点的图
        cycleScrollView.pageDotImage = [UIImage imageNamed:@"02"];
        
        cycleScrollView.placeholderImage = [UIImage imageNamed:@"C"];
        
        //        NSMutableArray *imageNames = [NSMutableArray arrayWithObjects:@"C",@"xq1",nil];
        //        SDCycleScrollView *cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 64, ScreenWidth, 314 * kPercent) imageNamesGroup:imageNames];
        cycleScrollView;
    });

}

#pragma tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    TriImgTextCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TriImgTextCell"];
    
    if (indexPath.row == 1) {
        
        ImgTextCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ImgTextCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
    }
    if (indexPath.row == 2) {
        MapCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MapCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 260;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    HouseDetailController *houseDetailVC = [[HouseDetailController alloc] init];
    houseDetailVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:houseDetailVC animated:YES];
}

//定位
- (void)locationAction{
    
    
}













- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
