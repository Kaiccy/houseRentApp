//
//  HouseDetailController.m
//  EHouse
//
//  Created by wx on 2016/12/22.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "HouseDetailController.h"
#import "HouseInfoCell.h"
#import "DetailMapCell.h"

@interface HouseDetailController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong)UITableView *tableView;

//图片数组
@property (nonatomic, strong) NSArray *bannerImgArr;

@end

@implementation HouseDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    kSetNavigationBar(@"")
    
    self.bannerImgArr = [NSArray arrayWithObjects:@"img_1",@"img_1",@"img_1",@"img_1", nil];
    
    [self addViews];

}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.translucent = YES;
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
}

- (void)addViews{
    
    //底部View
    UIView *bottomView = [[UIView alloc] init];
    [self.view addSubview:bottomView];
    bottomView.backgroundColor = [UIColor whiteColor];
    [bottomView makeConstraints:^(MASConstraintMaker *make) {
        
        make.bottom.left.right.equalTo(self.view);
        make.height.equalTo(49);
    }];

    //头像
    UIImageView *headImgV = [[UIImageView alloc] init];
    [bottomView addSubview:headImgV];
    headImgV.image = [UIImage imageNamed:@"headIconH"];
    headImgV.layer.masksToBounds = YES;
    headImgV.layer.cornerRadius = headImgV.bounds.size.width / 2;
    [headImgV makeConstraints:^(MASConstraintMaker *make) {
        
        make.width.equalTo(35);
        make.height.equalTo(35);
        make.top.equalTo(5);
        make.left.equalTo(12);
    }];
    
    //姓名
    UILabel *nameL = [[UILabel alloc] init];
    [bottomView addSubview:nameL];
    nameL.font = [UIFont systemFontOfSize:12];
    nameL.text = @"许绍均";
    [nameL makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(headImgV.right).equalTo(10);
        make.top.equalTo(5);
    }];
    
    //电话
    UILabel *phoneL = [[UILabel alloc] init];
    [bottomView addSubview:phoneL];
    phoneL.font = [UIFont systemFontOfSize:10];
    phoneL.textColor = kWordColor(102, 102, 102);
    phoneL.text = @"18324400999";
    [phoneL makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(headImgV.right).equalTo(10);
        make.top.equalTo(nameL.bottom).equalTo(5);
        make.width.equalTo(80);
    }];
    
    //小竖线
    UIView *lineV = [[UIView alloc] init];
    [bottomView addSubview:lineV];
    lineV.backgroundColor = kBackgroudColor;
    [lineV makeConstraints:^(MASConstraintMaker *make) {
        
        make.height.equalTo(25);
        make.width.equalTo(1);
        make.centerY.equalTo(bottomView);
        make.left.equalTo(phoneL.right).equalTo(24);
    }];
    
    //预约看房按钮
    UIButton *callBtn = [UIButton buttonWithType:(UIButtonTypeSystem)];
    [bottomView addSubview:callBtn];
    callBtn.tintColor = kBlueColor;
    [callBtn setTitle:@"预约看房" forState:(UIControlStateNormal)];
    callBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [callBtn setImage:[UIImage imageNamed:@"phone"] forState:(UIControlStateNormal)];
    callBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    callBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
    [callBtn addTarget:self action:@selector(checkHouse) forControlEvents:(UIControlEventTouchUpInside)];
    [callBtn makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(lineV.right).equalTo(30);
        make.height.equalTo(49);
        make.right.equalTo(0);
        make.centerY.equalTo(bottomView);
    }];
    
    
    //tableView
    self.tableView = [[UITableView alloc] init];
    [self.view addSubview:_tableView];
    [_tableView makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(0);
        make.left.right.equalTo(0);
        make.bottom.equalTo(-49);
    }];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerNib:[UINib nibWithNibName:@"HouseInfoCell" bundle:nil] forCellReuseIdentifier:@"HouseInfoCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"DetailMapCell" bundle:nil] forCellReuseIdentifier:@"DetailMapCell"];
    [self headerForTableView];
}

//headerView
- (void)headerForTableView{
    
    self.tableView.tableHeaderView = ({
    
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 69, ScreenWidth, 330 * kPercent)];
        
        //轮播图
        SDCycleScrollView *cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, ScreenWidth, 250 * kPercent) imageURLStringsGroup:_bannerImgArr];
        
        //当前点的图
        cycleScrollView.currentPageDotImage = [UIImage imageNamed:@"01"];
        //其他的点的图
        cycleScrollView.pageDotImage = [UIImage imageNamed:@"02"];
        
        cycleScrollView.placeholderImage = [UIImage imageNamed:@"img_1"];
        
        //        NSMutableArray *imageNames = [NSMutableArray arrayWithObjects:@"C",@"xq1",nil];
        //        SDCycleScrollView *cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 64, ScreenWidth, 314 * kPercent) imageNamesGroup:imageNames];
        [headerView addSubview:cycleScrollView];
        
        //小区名
        UILabel *ereaNameL = [[UILabel alloc] init];
        [headerView addSubview:ereaNameL];
        ereaNameL.text = @"万家星城·三期";
        [ereaNameL makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.equalTo(cycleScrollView.bottom).equalTo(15);
            make.left.equalTo(20);
            make.height.equalTo(17);
        }];
        
        //月租
        UILabel *rentL = [[UILabel alloc] init];
        [headerView addSubview:rentL];
        rentL.text = @"￥5200";
        rentL.textColor = kWordColor(255, 170, 0);
        [rentL makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(20);
            make.top.equalTo(ereaNameL.bottom).equalTo(15);
            make.bottom.equalTo(-20);
            make.height.equalTo(17);
        }];
        
        UILabel *monthL = [[UILabel alloc] init];
        [headerView addSubview:monthL];
        monthL.font = [UIFont systemFontOfSize:11];
        monthL.text = @"/月";
        monthL.textColor = kWordColor(255, 170, 0);
        [monthL makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(rentL.right).equalTo(5);
            make.bottom.equalTo(rentL);
        }];
        
        headerView;
    });
}

#pragma tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    HouseInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HouseInfoCell"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if (indexPath.row == 1) {
        DetailMapCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailMapCell"];
        
        return cell;
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 380;
}

//预约看房
- (void)checkHouse{
    
    NSString *phoneNumber = @"0571-87783552";
    UIWebView *callWebview =[[UIWebView alloc] init];
    
    NSURL *telURL =[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",phoneNumber]];
    [callWebview loadRequest:[NSURLRequest requestWithURL:telURL]];
    //记得添加到view上
    [self.view addSubview:callWebview];
    
}

- (void)back{
    
    [self.navigationController popViewControllerAnimated:YES];
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
