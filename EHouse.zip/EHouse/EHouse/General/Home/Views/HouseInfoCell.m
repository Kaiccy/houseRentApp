//
//  HouseInfoCell.m
//  EHouse
//
//  Created by wx on 2016/12/22.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "HouseInfoCell.h"

@interface HouseInfoCell ()

//位置描述
@property (weak, nonatomic) IBOutlet UILabel *locationL;

//户型描述
@property (weak, nonatomic) IBOutlet UILabel *TypeDescL;

//配置描述
@property (weak, nonatomic) IBOutlet UILabel *deviceDescL;

@end

@implementation HouseInfoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    //位置描述
    NSMutableAttributedString *locationStr=[[NSMutableAttributedString alloc]initWithString:@"位置描述：该小区位于西兴商圈，周边还有公交站点：江陵路滨和路口，迎春小区，公交江陵路江汉路口站 等，出门十分方便。"];
    //获取要调整颜色的文字位置,调整颜色
    NSRange range1=[[locationStr string] rangeOfString:@"位置描述："];
    [locationStr addAttribute:NSForegroundColorAttributeName value:kWordColor(102, 102, 102) range:range1];
    _locationL.attributedText = locationStr;
    
    //户型描述
    NSMutableAttributedString *typeStr=[[NSMutableAttributedString alloc]initWithString:@"户型描述：1室1阳台，朝南且采光充足，室内很明亮，通风状况良好，让您可以享受阳光的味道和自然的呼 吸。"];
    //获取要调整颜色的文字位置,调整颜色
    NSRange range2=[[typeStr string] rangeOfString:@"户型描述："];
    [typeStr addAttribute:NSForegroundColorAttributeName value:kWordColor(102, 102, 102) range:range2];
    _TypeDescL.attributedText = typeStr;
    
    //配置描述
    NSMutableAttributedString *deviceStr=[[NSMutableAttributedString alloc]initWithString:@"配置描述：房间内铺了优质木地板，家电配置都很齐全，让您拥有便利居家的享受。"];
    //获取要调整颜色的文字位置,调整颜色
    NSRange range3=[[deviceStr string] rangeOfString:@"配置描述："];
    [deviceStr addAttribute:NSForegroundColorAttributeName value:kWordColor(102, 102, 102) range:range3];
    _deviceDescL.attributedText = deviceStr;
    
    
}







- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
