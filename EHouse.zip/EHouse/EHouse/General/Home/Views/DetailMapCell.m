//
//  DetailMapCell.m
//  EHouse
//
//  Created by wx on 2016/12/22.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "DetailMapCell.h"

@implementation DetailMapCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
