//
//  SegmentView.h
//  EHouse
//
//  Created by wx on 2016/12/26.
//  Copyright © 2016年 wx. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SegmentViewDelegate <NSObject>

- (void)showList:(UIButton *)button;

@end

@interface SegmentView : UIView

@property (strong, nonatomic) NSArray *titleArr;

//代理
@property (assign, nonatomic) id<SegmentViewDelegate> delegate;

@end
