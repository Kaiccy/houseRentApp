//
//  WXSearchBar.h
//  demo
//
//  Created by wx on 2016/12/28.
//  Copyright © 2016年 wx. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WXSearchBar;

@protocol WXSearchBarDelegate <NSObject>

@optional

- (BOOL)searchBarShouldBeginEditing:(WXSearchBar *)searchBar;
- (void)searchBarTextDidBeginEditing:(WXSearchBar *)searchBar;
- (BOOL)searchBarShouldEndEditing:(WXSearchBar *)searchBar;
- (void)searchBarTextDidEndEditing:(WXSearchBar *)searchBar;
- (void)searchBar:(WXSearchBar *)searchBar textDidChange:(NSString *)searchText;
- (void)searchBarSearchButtonClicked:(WXSearchBar *)searchBar; //确定搜索按钮
- (void)searchBarCancleButtonClicked:(WXSearchBar *)searchBar; //取消搜索按钮

@end

@interface WXSearchBar : UIView

//文本颜色
@property (strong, nonatomic) UIColor *textColor;

//字体
@property (strong, nonatomic) UIFont *searchBarFont;

//内容
@property (strong, nonatomic) NSString *text;

//背景颜色
@property (strong, nonatomic) UIColor *searchBarColor;

//默认文本
@property (strong, nonatomic) NSString *placeHolder;

//默认文本的颜色
@property (strong, nonatomic) UIColor *placeHolderColor;

//默认文本字体大小
@property (strong, nonatomic) UIFont *placeHolderFont;

//是否弹出键盘
@property (assign, nonatomic) BOOL isBecomeFirstResponder;

//设置右边删除按钮的样式
@property (strong, nonatomic) UIImage *deleteImage;

//设置渲染色
@property (strong, nonatomic) UIColor *tintColor;

//代理
@property (assign, nonatomic) id<WXSearchBarDelegate> delegate;


@end
