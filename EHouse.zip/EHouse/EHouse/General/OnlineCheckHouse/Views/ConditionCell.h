//
//  ConditionCell.h
//  EHouse
//
//  Created by wx on 2016/12/27.
//  Copyright © 2016年 wx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConditionCell : UITableViewCell

@property (nonatomic, strong) UILabel *lable;

@end
