//
//  ServiceCell.h
//  EHouse
//
//  Created by wx on 2016/12/30.
//  Copyright © 2016年 wx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServiceCell : UITableViewCell

@property (strong, nonatomic) NSString *title;
@property (strong, nonatomic) NSString *imgStr;

@end
