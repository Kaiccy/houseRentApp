//
//  WXSearchBar.m
//  demo
//
//  Created by wx on 2016/12/28.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "WXSearchBar.h"

@interface WXSearchBar ()<UITextFieldDelegate>

@property (nonatomic, strong) UITextField *textFeild;
//@property (nonatomic, strong) UIButton *deleteButton;
@property (nonatomic, strong) UIImageView *leftImgVeiw;
@property (nonatomic, strong) UIButton *cancleButton;
@property (nonatomic, strong) UIView *containerView;

//小竖线
@property (nonatomic, strong) UIView *lineView;

@end

@implementation WXSearchBar

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self initAllviews];
    }
    return self;
}

- (void)initAllviews{
    
    if (_containerView == nil) {
        self.containerView = [[UIView alloc] init];
        [self addSubview:_containerView];
        [_containerView makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.left.bottom.equalTo(0);
            make.width.equalTo(self.bounds.size.width - 45);
        }];
    }
    self.containerView.layer.masksToBounds = YES;
    self.containerView.layer.cornerRadius = 5;
    
    //搜索图标
    if (_leftImgVeiw == nil) {
        
        self.leftImgVeiw = [[UIImageView alloc] init];
        [_containerView addSubview:_leftImgVeiw];
        _leftImgVeiw.image = [UIImage imageNamed:@"search"];
        _leftImgVeiw.contentMode = UIViewContentModeScaleAspectFit;
        [_leftImgVeiw makeConstraints:^(MASConstraintMaker *make) {
            
            make.height.width.equalTo(15);
            make.left.equalTo(10);
            make.centerY.equalTo(self);
        }];
    }
    
    //竖线
    if (_lineView == nil) {
        self.lineView = [[UIView alloc] init];
        [_containerView addSubview:_lineView];
        [_lineView makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(35);
            make.height.equalTo(15);
            make.width.equalTo(1);
            make.centerY.equalTo(self);
        }];
    }
    
    //输入框
    if (_textFeild == nil) {
        
        self.textFeild = [[UITextField alloc] init];
        [self.containerView addSubview:_textFeild];
        [_textFeild makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(_lineView.right).equalTo(10);
            make.top.bottom.equalTo(_containerView);
            make.right.equalTo(0);
        }];
    }
    
    //取消按钮
    if (_cancleButton == nil) {
        
        self.cancleButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
        [self addSubview:_cancleButton];
        _cancleButton.titleLabel.font = [UIFont systemFontOfSize:14];
        [_cancleButton setTitle:@"取消" forState:(UIControlStateNormal)];
        [_cancleButton makeConstraints:^(MASConstraintMaker *make) {
            
            make.width.equalTo(30);
            make.left.equalTo(_containerView.right).equalTo(15);
            make.right.equalTo(0);
            make.centerY.equalTo(self);
        }];
        
        [_cancleButton addTarget:self action:@selector(cancleButtonAction:) forControlEvents:(UIControlEventTouchUpInside)];
    }
    
}

//set方法
- (void)setIsBecomeFirstResponder:(BOOL)isBecomeFirstResponder{
    
    _isBecomeFirstResponder = isBecomeFirstResponder;
    if (_isBecomeFirstResponder) {
        [_textFeild becomeFirstResponder];
    }
}

- (void)setSearchBarColor:(UIColor *)searchBarColor{
    
    _searchBarColor = searchBarColor;
    _containerView.backgroundColor = _searchBarColor;
}

- (void)setSearchBarFont:(UIFont *)searchBarFont{
    
    _searchBarFont = searchBarFont;
    _textFeild.font = _searchBarFont;
}

-(void)setTextColor:(UIColor *)textColor{
    
    _textColor = textColor;
    _textFeild.textColor = _textColor;
    
}

- (void)setPlaceHolder:(NSString *)placeHolder{
    
    _placeHolder = placeHolder;
    _textFeild.placeholder = placeHolder;
}

- (void)setPlaceHolderColor:(UIColor *)placeHolderColor{
    
    _placeHolderColor = placeHolderColor;
//    [_textFeild setValue:[UIColor whiteColor] forKey:@"_placeholderLabel.textColor"];
}

- (void)setPlaceHolderFont:(UIFont *)placeHolderFont{
    
    _placeHolderFont = placeHolderFont;
//    [_textFeild setValue:_placeHolderFont forKey:@"_placeholderLabel.font"];
}

- (void)setText:(NSString *)text{
    
    _text = text;
    _textFeild.text = _text;
}

- (void)setTintColor:(UIColor *)tintColor{
    
    _tintColor = tintColor;
    _lineView.backgroundColor = _tintColor;
    _cancleButton.tintColor = _tintColor;
}

//点击取消按钮
- (void)cancleButtonAction:(UIButton *)button{
    
    _textFeild.text = @"";
    [self.delegate searchBarCancleButtonClicked:self];
}

@end


















