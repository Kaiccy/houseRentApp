//
//  SegmentView.m
//  EHouse
//
//  Created by wx on 2016/12/26.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "SegmentView.h"

#define kWidth self.bounds.size.width / 4
#define kHeight self.bounds.size.height

@implementation SegmentView

- (void)layoutSubviews{
    
    self.backgroundColor = [UIColor whiteColor];
    self.titleArr = [NSArray arrayWithObjects:@"区域",@"租金",@"面积",@"承租方式", nil];
    
    //上线
    UIView *line1 = [[UIView alloc] init];
    [self addSubview:line1];
    line1.backgroundColor = kLineColor;
    [line1 makeConstraints:^(MASConstraintMaker *make) {
        
        make.height.equalTo(1);
        make.width.equalTo(self);
        make.top.left.equalTo(self);
    }];
    
    //下线
    UIView *line2 = [[UIView alloc] init];
    [self addSubview:line2];
    line2.backgroundColor = kLineColor;
    [line2 makeConstraints:^(MASConstraintMaker *make) {
        
        make.height.equalTo(1);
        make.width.equalTo(self);
        make.bottom.left.equalTo(self);
    }];
    
    //四个按钮
    for (int i = 0; i < 4; i ++) {
        
        UIButton *button = [UIButton buttonWithType:(UIButtonTypeSystem)];
        [self addSubview:button];
        [button makeConstraints:^(MASConstraintMaker *make) {
            
            make.height.equalTo(kHeight - 2);
            make.width.equalTo(kWidth);
            make.left.equalTo(kWidth * i);
            make.centerY.equalTo(self);
        }];
        
        [button setTitle:_titleArr[i] forState:(UIControlStateNormal)];
        [button setTitleColor:kWordColor(153, 153, 153) forState:(UIControlStateNormal)];
        button.titleLabel.font = [UIFont systemFontOfSize:14];
        
        button.tag = 100 + i;
        [button addTarget:self action:@selector(clickAction:) forControlEvents:(UIControlEventTouchUpInside)];
        
    }
}

- (void)clickAction:(UIButton *)button{
    
    [self.delegate showList:button];
}

@end
