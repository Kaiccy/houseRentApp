//
//  HouseListCell.m
//  EHouse
//
//  Created by wx on 2016/12/23.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "HouseListCell.h"

@interface HouseListCell ()

@property (weak, nonatomic) IBOutlet UILabel *rentWayL;

@end

@implementation HouseListCell

- (void)awakeFromNib {
    [super awakeFromNib];

    _rentWayL.layer.masksToBounds = YES;
    _rentWayL.layer.cornerRadius = 2;
    _rentWayL.layer.borderColor = kBlueColor.CGColor;
    _rentWayL.layer.borderWidth = 1;

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

@end
