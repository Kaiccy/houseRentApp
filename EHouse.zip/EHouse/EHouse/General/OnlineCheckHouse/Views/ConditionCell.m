//
//  ConditionCell.m
//  EHouse
//
//  Created by wx on 2016/12/27.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "ConditionCell.h"

@interface ConditionCell ()



@end

@implementation ConditionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    

}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.lable = [[UILabel alloc] init];
        [self addSubview:_lable];
        _lable.text = @"合租";
        _lable.font = [UIFont systemFontOfSize:15];
        _lable.textAlignment = NSTextAlignmentCenter;
        [_lable makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.left.right.bottom.equalTo(self);
        }];
        
        //line
        UIView *line = [[UIView alloc] init];
        [self addSubview:line];
        line.backgroundColor = kLineColor;
        [line makeConstraints:^(MASConstraintMaker *make) {
            
            make.height.equalTo(1);
            make.bottom.equalTo(self);
            make.left.equalTo(20);
            make.right.equalTo(-20);
        }];
    }
    
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
