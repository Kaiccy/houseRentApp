//
//  ServiceCell.m
//  EHouse
//
//  Created by wx on 2016/12/30.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "ServiceCell.h"

@interface ServiceCell ()

@property (weak, nonatomic) IBOutlet UIImageView *backImgV;

@property (weak, nonatomic) IBOutlet UILabel *titleL;

@end

@implementation ServiceCell

- (void)awakeFromNib {
    [super awakeFromNib];

}

- (void)setTitle:(NSString *)title{
    
    _titleL.text = title;
}

- (void)setImgStr:(NSString *)imgStr{
    
    _backImgV.image = [UIImage imageNamed:imgStr];
}












- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
