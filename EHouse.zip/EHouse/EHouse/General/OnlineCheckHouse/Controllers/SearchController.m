//
//  SearchController.m
//  EHouse
//
//  Created by wx on 2016/12/28.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "SearchController.h"
#import "WXSearchBar.h"

@interface SearchController ()<WXSearchBarDelegate>

@property (nonatomic, strong) WXSearchBar *searchBar;

@end

@implementation SearchController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setSearchView];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"HouseListCell" bundle:nil] forCellReuseIdentifier:@"HouseListCell"];
}

//设置searchView
- (void)setSearchView{
    
    self.navigationItem.hidesBackButton = YES;
    
    self.searchBar = [[WXSearchBar alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth - 40, 30)];
    self.navigationItem.titleView = self.searchBar;
    _searchBar.searchBarFont = [UIFont systemFontOfSize:12];
    _searchBar.tintColor = kGrayColor;
    _searchBar.placeHolderColor =kGrayColor;
    _searchBar.searchBarColor = kWordColor(242, 242, 241);
    _searchBar.placeHolder = @"请输入搜索内容";
    _searchBar.delegate = self;
    
}

#pragma tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    HouseListCell *cell =  [tableView dequeueReusableCellWithIdentifier:@"HouseListCell"];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 132 * kPercent;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    HouseDetailController *houseDetailVC = [[HouseDetailController alloc] init];
    [self.navigationController pushViewController:houseDetailVC animated:YES];
    
}

#pragma WXSearchBarDelegate
- (void)searchBarCancleButtonClicked:(WXSearchBar *)searchBar{
    
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
