//
//  SearchController.h
//  EHouse
//
//  Created by wx on 2016/12/28.
//  Copyright © 2016年 wx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchController : UITableViewController

@end
