//
//  OnlineCheckHouseController.m
//  E_House
//
//  Created by wx on 2016/12/13.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "OnlineCheckHouseController.h"
#import "SearchController.h"
#import "SegmentView.h"
#import "ConditionCell.h"
#import "ServiceCell.h"

@interface OnlineCheckHouseController ()<UITableViewDelegate,UITableViewDataSource,UIGestureRecognizerDelegate,SegmentViewDelegate>

//房屋查看按钮
@property (nonatomic, strong) UIButton *checkHouseBtn;

//周边服务
@property (nonatomic, strong) UIButton *serviceBtn;

//房屋列表
@property (nonatomic, strong) UITableView *tableView;

//筛选列表
@property (nonatomic, strong) UITableView *conditionTableView;

//segment
@property (nonatomic, strong) SegmentView *segmentV;

//周边服务列表
@property(nonatomic, strong) UITableView *serviceTable;

//筛选条件的数组
@property (nonatomic, strong) NSMutableArray *conditionArr;

//周边服务的数组
@property (nonatomic, strong) NSArray *serviceTitleArr;
@property (nonatomic, strong) NSArray *serviceImgArr;

@end

@implementation OnlineCheckHouseController

//- (UIStatusBarStyle)preferredStatusBarStyle {
//    return UIStatusBarStyleLightContent;
//}

- (NSMutableArray *)conditionArr{
    
    if (_conditionArr == nil) {
        self.conditionArr = [NSMutableArray array];
    }
    return _conditionArr;
}

- (void)viewWillAppear:(BOOL)animated{
    
    self.navigationController.navigationBar.translucent = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setNavigationBar];
    
    [self addViews];
    
    self.serviceTitleArr = [NSArray arrayWithObjects:@"周边楼盘",@"家政服务", nil];
    self.serviceImgArr = [NSArray arrayWithObjects:@"img_00003",@"img_00002", nil];
    
    //添加手势隐藏条件列表
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideConditionTableView)];
    tap.delegate = self;
    [self.conditionTableView addGestureRecognizer:tap];
    
}

//定义navigationBar
- (void)setNavigationBar{
    
    UIView *navView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 190 * kPercent, 35)];
    self.navigationItem.titleView = navView;
    navView.layer.masksToBounds = YES;
    navView.layer.cornerRadius = 5;
    navView.layer.borderWidth = 1;
    navView.layer.borderColor = kBlueColor.CGColor;
    
    //房屋查看
    UIButton *checkHouseBtn = [UIButton buttonWithType:(UIButtonTypeSystem)];
    [navView addSubview:checkHouseBtn];
    checkHouseBtn.layer.masksToBounds = YES;
    checkHouseBtn.layer.cornerRadius = 2.5;
    checkHouseBtn.backgroundColor = kBlueColor;
    checkHouseBtn.tintColor = [UIColor whiteColor];
    [checkHouseBtn setTitle:@"房屋查看" forState:(UIControlStateNormal)];
    checkHouseBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    checkHouseBtn.tag = 200;
    [checkHouseBtn addTarget:self action:@selector(checkHouseAction:) forControlEvents:(UIControlEventTouchUpInside)];
    [checkHouseBtn makeConstraints:^(MASConstraintMaker *make) {
        
        make.centerY.equalTo(navView);
        make.width.equalTo(90 * kPercent);
        make.height.equalTo(30);
        make.left.equalTo(3);
    }];
    self.checkHouseBtn = checkHouseBtn;
    
    //周边服务
    UIButton *serviceBtn = [UIButton buttonWithType:(UIButtonTypeSystem)];
    [navView addSubview:serviceBtn];
    serviceBtn.layer.masksToBounds = YES;
    serviceBtn.layer.cornerRadius = 2.5;
    [serviceBtn setTitle:@"周边服务" forState:(UIControlStateNormal)];
    serviceBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    serviceBtn.tintColor = kBlueColor;
    serviceBtn.tag = 201;
    [serviceBtn addTarget:self action:@selector(checkHouseAction:) forControlEvents:(UIControlEventTouchUpInside)];
    [serviceBtn makeConstraints:^(MASConstraintMaker *make) {
        
        make.centerY.equalTo(navView);
        make.width.equalTo(90 * kPercent);
        make.height.equalTo(30);
        make.right.equalTo(-3);
    }];
    self.serviceBtn = serviceBtn;
    
    //搜索按钮
    self.navigationItem.rightBarButtonItem.tintColor = kBlueColor;
}

- (void)addViews{
    
//    SegmentView
    self.segmentV = [[SegmentView alloc] init];
    [self.view addSubview:_segmentV];
    _segmentV.delegate = self;
    [_segmentV makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.right.top.equalTo(self.view);
        make.height.equalTo(45);
    }];
    
//    tableView
    self.tableView = [[UITableView alloc] init];
    [self.view addSubview:_tableView];
    [_tableView makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(_segmentV.bottom);
        make.left.right.equalTo(self.view);
        make.bottom.equalTo(0);
    }];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    [self.tableView registerNib:[UINib nibWithNibName:@"HouseListCell" bundle:nil] forCellReuseIdentifier:@"HouseListCell"];
    
    //条件tableView
    self.conditionTableView = [[UITableView alloc] init];
    [self.view addSubview:_conditionTableView];
    [_conditionTableView makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(_segmentV.bottom);
        make.left.right.equalTo(self.view);
        make.height.equalTo(0);
    }];
    self.conditionTableView.separatorStyle = UITableViewCellSelectionStyleNone;
    self.conditionTableView.backgroundColor = [UIColor colorWithRed:0/255. green:0/255. blue:0/255. alpha:0.5];
    self.conditionTableView.delegate = self;
    self.conditionTableView.dataSource = self;
    [self.conditionTableView registerClass:[ConditionCell class] forCellReuseIdentifier:@"ConditionCell"];
    
    //serviceTable
    self.serviceTable = [[UITableView alloc] init];
    [self.view addSubview:_serviceTable];
    _serviceTable.delegate = self;
    _serviceTable.dataSource = self;
    [_serviceTable registerNib:[UINib nibWithNibName:@"ServiceCell" bundle:nil] forCellReuseIdentifier:@"ServiceCell"];
    _serviceTable.hidden = YES;
    _serviceTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    [_serviceTable makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.right.top.bottom.equalTo(self.view);
    }];
}

#pragma  tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (tableView == _tableView) {
        return 10;
    }
    if (tableView == _conditionTableView) {
        return _conditionArr.count;
    }
    if (tableView == _serviceTable) {
        return 2;
    }
    
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if (tableView == _tableView) {
        HouseListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HouseListCell"];
        
        return cell;
    }
    
    if (tableView == _conditionTableView) {
        ConditionCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ConditionCell"];
        
        cell.lable.text = _conditionArr[indexPath.row];
        
        return cell;

    }
    
    if (tableView == _serviceTable) {
        ServiceCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ServiceCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        cell.title = _serviceTitleArr[indexPath.row];
        cell.imgStr = _serviceImgArr[indexPath.row];
        
        return cell;
    }
    
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (tableView == _tableView) {
        return 132 * kPercent;
    }
    if (tableView == _conditionTableView) {
        return 45 * kPercent;
    }
    if (tableView == _serviceTable) {
        return 180 * kPercent;
    }
    
    return 132 * kPercent;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _tableView) {
        
        HouseDetailController *houseDetailVC = [[HouseDetailController alloc] init];
        houseDetailVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:houseDetailVC animated:YES];
    }
    if (tableView == _conditionTableView) {
        
        [self hideConditionTableView];
    }
    
}


#pragma segmentDelegate
- (void)showList:(UIButton *)button{
    
    NSLog(@"点击，点击%ld",(long)button.tag);
    
    if (button.tag == 100) {
        //区域
        
        [self showConditionTableView];
        [self.conditionArr removeAllObjects];
        [self.conditionArr addObjectsFromArray:[NSArray arrayWithObjects:@"全城",@"江干区",@"上城区",@"下城区",@"拱墅区",@"西湖区",@"滨江区",@"萧山区",@"余杭区",nil]];
        [_conditionTableView reloadData];
        
    }else if (button.tag == 101){
        //租金
        
        [self showConditionTableView];
        [self.conditionArr removeAllObjects];
        [self.conditionArr addObjectsFromArray:[NSArray arrayWithObjects:@"不限",@"0~1000元",@"1000~2000元",@"2000~3000元",@"3000元以上",nil]];
        [_conditionTableView reloadData];
        
    }else if (button.tag == 102){
        //面积
        
        [self showConditionTableView];
        [self.conditionArr removeAllObjects];
        [self.conditionArr addObjectsFromArray:[NSArray arrayWithObjects:@"不限",@"0~30m²",@"30~50m²",@"50~80m²",@"80~120m²",@"120m²以上",nil]];
        [_conditionTableView reloadData];
        
    }else if (button.tag == 103){
        //承租方式
        
        [self showConditionTableView];
        [self.conditionArr removeAllObjects];
        [self.conditionArr addObjectsFromArray:[NSArray arrayWithObjects:@"不限",@"合租",@"整租",nil]];
        [_conditionTableView reloadData];
    }
}

#pragma titleVciew 的点击按钮
- (void)checkHouseAction:(UIButton *)button{
    
    button.backgroundColor = kBlueColor;
    button.tintColor = [UIColor whiteColor];
    
    if (button.tag == 200) {
        //房屋查看
        NSLog(@"===%ld",(long)button.tag);
        
        _serviceTable.hidden = YES;
        _serviceBtn.backgroundColor = [UIColor whiteColor];
        _serviceBtn.tintColor = kBlueColor;
    }
    
    if (button.tag == 201) {
        //周边服务
        NSLog(@"===%ld",(long)button.tag);
        
        _serviceTable.hidden = NO;
        _checkHouseBtn.backgroundColor = [UIColor whiteColor];
        _checkHouseBtn.tintColor = kBlueColor;
    }
}

#pragma 搜索按钮
- (IBAction)searchAction:(UIBarButtonItem *)sender {
    
    NSLog(@"搜索");
    SearchController *searchVC = [[SearchController alloc]  init];
    searchVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:searchVC animated:YES];
}

#pragma 隐藏展开条件列表

- (void)showConditionTableView{
    
    [_conditionTableView updateConstraints:^(MASConstraintMaker *make) {
        
        make.height.equalTo(ScreenHeight - 64 - 45 - 49);
    }];
}

- (void)hideConditionTableView{
    
    [_conditionTableView updateConstraints:^(MASConstraintMaker *make) {
        
        make.height.equalTo(0);
    }];
}

#pragma UIGestureRecognizerDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    // 输出点击的view的类名
    NSLog(@"%@", NSStringFromClass([touch.view class]));
    
    // 若为UITableViewCellContentView（即点击了tableViewCell），则不截获Touch事件
    if ([NSStringFromClass([touch.view class]) isEqualToString:@"UITableViewCellContentView"]) {
        return NO;
    }
    return  YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
