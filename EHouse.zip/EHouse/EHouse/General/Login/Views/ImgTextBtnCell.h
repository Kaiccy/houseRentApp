//
//  ImgTextBtnCell.h
//  EHouse
//
//  Created by wx on 2016/12/30.
//  Copyright © 2016年 wx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImgTextBtnCell : UITableViewCell

@property (strong, nonatomic) NSString *placeHolderStr;
@property (strong, nonatomic) NSString *imgStr;

//是否隐藏验证按钮
@property (assign, nonatomic) BOOL isHidden;

@end
