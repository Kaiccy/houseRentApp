//
//  ButtonCell.h
//  EHouse
//
//  Created by wx on 2017/1/3.
//  Copyright © 2017年 wx. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol  ButtonCellDelegate <NSObject>

- (void)buttonCellAction:(NSString *)buttonTitle;

@end

@interface ButtonCell : UITableViewCell

@property (strong, nonatomic) NSString *title;

//按钮的背景色
@property (strong, nonatomic) UIColor *bgColor;
@property (strong, nonatomic) UIColor *titleColor;

//代理
@property (assign, nonatomic) id<ButtonCellDelegate> delegate;

@end
