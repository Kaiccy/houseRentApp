//
//  ButtonCell.m
//  EHouse
//
//  Created by wx on 2017/1/3.
//  Copyright © 2017年 wx. All rights reserved.
//

#import "ButtonCell.h"

@interface ButtonCell ()

@property (nonatomic, strong)UIButton *defineButton;

@end

@implementation ButtonCell

- (void)awakeFromNib {
    [super awakeFromNib];

}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        self.defineButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
        [self addSubview:_defineButton];
        [_defineButton addTarget:self action:@selector(clickAction:) forControlEvents:(UIControlEventTouchUpInside)];
        [_defineButton makeConstraints:^(MASConstraintMaker *make) {
            
            make.width.equalTo(250 * kPercent);
            make.centerX.equalTo(self);
            make.top.equalTo(15);
            make.bottom.equalTo(0);
            make.height.equalTo(40 * kPercent);
        }];
        
        _defineButton.backgroundColor = kBlackColor;
        [_defineButton setTintColor:kYellowColor];
        _defineButton.titleLabel.font = [UIFont systemFontOfSize:19];
        _defineButton.layer.masksToBounds = YES;
        _defineButton.layer.cornerRadius = 20 * kPercent;
        _defineButton.layer.borderColor = kBlackColor.CGColor;
        _defineButton.layer.borderWidth = 1;
    }
    
    return self;
}

- (void)setTitle:(NSString *)title{
    
    [_defineButton setTitle:title forState:(UIControlStateNormal)];
}

- (void)setBgColor:(UIColor *)bgColor{
    
    _defineButton.backgroundColor = bgColor;
}

- (void)setTitleColor:(UIColor *)titleColor{
    
    _defineButton.tintColor = titleColor;
}

//点击事件
- (void)clickAction:(UIButton *)button{
    
    [self.delegate buttonCellAction:button.titleLabel.text];
}







- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
