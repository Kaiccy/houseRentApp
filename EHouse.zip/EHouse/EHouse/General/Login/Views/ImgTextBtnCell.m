//
//  ImgTextBtnCell.m
//  EHouse
//
//  Created by wx on 2016/12/30.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "ImgTextBtnCell.h"

@interface ImgTextBtnCell ()

//输入框
@property (weak, nonatomic) IBOutlet UITextField *textField;

//获取验证码
@property (weak, nonatomic) IBOutlet UIButton *getVerifyCodeBtn;

//横线
@property (weak, nonatomic) IBOutlet UILabel *lineL;

//小图标
@property (weak, nonatomic) IBOutlet UIImageView *imgV;


@end

@implementation ImgTextBtnCell

- (void)awakeFromNib {
    [super awakeFromNib];


    _getVerifyCodeBtn.layer.masksToBounds = YES;
    _getVerifyCodeBtn.layer.cornerRadius = 10;
}

- (void)setPlaceHolderStr:(NSString *)placeHolderStr{
    
    _textField.placeholder = placeHolderStr;
}

- (void)setImgStr:(NSString *)imgStr{
    
    _imgV.image = [UIImage imageNamed:imgStr];
}

- (void)setIsHidden:(BOOL)isHidden{
    
    _getVerifyCodeBtn.hidden = isHidden;
}

- (IBAction)getVerifyCodeAction:(UIButton *)sender {
    
    
}














- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
