//
//  LoginController.m
//  EHouse
//
//  Created by wx on 2016/12/30.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "LoginController.h"
#import "ImgTextBtnCell.h"
#import "ButtonCell.h"

@interface LoginController ()<UITableViewDelegate,UITableViewDataSource,ButtonCellDelegate>

@property (weak, nonatomic) IBOutlet UILabel *titleL;

@property (weak, nonatomic) IBOutlet UILabel *agreeL;
@property (weak, nonatomic) IBOutlet UIButton *protocolBtn;
@property (weak, nonatomic) IBOutlet UIButton *forgetPasswordBtn;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;

//tableView
@property (strong, nonatomic)UITableView *loginTableView;
@property (strong, nonatomic)UITableView *registerTableView;
@property (strong, nonatomic)UITableView *forgetTableView;

//scrollView的contenView
@property (weak, nonatomic) IBOutlet UIView *contentV;

//切换界面
@property (strong, nonatomic) UIView *loginV;
@property (strong, nonatomic) UIView *registerV;
@property (strong, nonatomic) UIView *forgetPasswordV;

//placeHolder 数组
@property(nonatomic, strong) NSArray *placeHolderArr;

//小图标
@property(nonatomic, strong) NSArray *imgArr;

@end

@implementation LoginController

- (void)viewDidLoad {
    [super viewDidLoad];


    self.placeHolderArr = [NSArray arrayWithObjects:@"请输入手机号码",@"请输入密码",@"请输入验证码", nil];
    self.imgArr = [NSArray arrayWithObjects:@"loginPhone",@"password",@"verifyCode", nil];

    [self addViews];
}

//添加Views
- (void)addViews{
    _loginBtn.hidden = YES;
    
    self.loginV = [[UIView alloc] init];
    [self.contentV addSubview:_loginV];
    [_loginV makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.bottom.equalTo(0);
        make.left.equalTo(0);
        make.width.equalTo(ScreenWidth);
    }];
    
    self.registerV = [[UIView alloc] init];
    [self.contentV addSubview:_registerV];
    [_registerV makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.bottom.equalTo(0);
        make.left.equalTo(ScreenWidth);
        make.width.equalTo(ScreenWidth);
    }];
    
    self.forgetPasswordV = [[UIView alloc] init];
    [self.contentV addSubview:_forgetPasswordV];
    [_forgetPasswordV makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.bottom.equalTo(0);
        make.left.equalTo(ScreenWidth * 2);
        make.width.equalTo(ScreenWidth);
    }];
    
    //背景
    UIImageView *backImgV1 = [[UIImageView alloc] init];
    backImgV1.image = [UIImage imageNamed:@"loginBackground"];
    [_loginV addSubview:backImgV1];
    [backImgV1 makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.left.bottom.right.equalTo(0);
    }];
    
    UIImageView *backImgV2 = [[UIImageView alloc] init];
    backImgV2.image = [UIImage imageNamed:@"loginBackground"];
    [_registerV addSubview:backImgV2];
    [backImgV2 makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.left.bottom.right.equalTo(0);
    }];
    
    UIImageView *backImgV3 = [[UIImageView alloc] init];
    backImgV3.image = [UIImage imageNamed:@"loginBackground"];
    [_forgetPasswordV addSubview:backImgV3];
    [backImgV3 makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.left.bottom.right.equalTo(0);
    }];
    
    //tableView
    //登录
    self.loginTableView = [[UITableView alloc] init];
    [self.loginV addSubview:_loginTableView];
    _loginTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [_loginTableView makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(30);
        make.right.equalTo(-30);
        make.top.equalTo(65 * kPercent);
        make.bottom.equalTo(-30);
    }];
    _loginTableView.dataSource = self;
    _loginTableView.delegate = self;
    [_loginTableView registerNib:[UINib nibWithNibName:@"ImgTextBtnCell" bundle:nil] forCellReuseIdentifier:@"ImgTextBtnCell"];
    [_loginTableView registerClass:[ButtonCell class] forCellReuseIdentifier:@"ButtonCell"];
    
    //注册
    self.registerTableView = [[UITableView alloc] init];
    [self.registerV addSubview:_registerTableView];
    _registerTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [_registerTableView makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(30);
        make.right.equalTo(-30);
        make.top.equalTo(65 * kPercent);
        make.bottom.equalTo(-30);
    }];
    _registerTableView.dataSource = self;
    _registerTableView.delegate = self;
    [_registerTableView registerNib:[UINib nibWithNibName:@"ImgTextBtnCell" bundle:nil] forCellReuseIdentifier:@"ImgTextBtnCell"];
    [_registerTableView registerClass:[ButtonCell class] forCellReuseIdentifier:@"ButtonCell"];
    
    //忘记密码
    self.forgetTableView = [[UITableView alloc] init];
    [self.forgetPasswordV addSubview:_forgetTableView];
    _forgetTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [_forgetTableView makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(30);
        make.right.equalTo(-30);
        make.top.equalTo(65 * kPercent);
        make.bottom.equalTo(-30);
    }];
    _forgetTableView.dataSource = self;
    _forgetTableView.delegate = self;
    [_forgetTableView registerNib:[UINib nibWithNibName:@"ImgTextBtnCell" bundle:nil] forCellReuseIdentifier:@"ImgTextBtnCell"];
    [_forgetTableView registerClass:[ButtonCell class] forCellReuseIdentifier:@"ButtonCell"];
    
    //标题
    UILabel *loginL = [[UILabel alloc] init];
    [_loginV addSubview:loginL];
    loginL.text = @"登     录";
    loginL.font = [UIFont systemFontOfSize:19];
    loginL.textColor = kBlackColor;
    [loginL makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(30 * kPercent);
        make.centerX.equalTo(_loginV);
    }];
    
    UILabel *registerL = [[UILabel alloc] init];
    [_registerV addSubview:registerL];
    registerL.text = @"注      册";
    registerL.font = [UIFont systemFontOfSize:19];
    registerL.textColor = kBlackColor;
    [registerL makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(30 * kPercent);
        make.centerX.equalTo(_registerV);
    }];
    
    UILabel *forgetL = [[UILabel alloc] init];
    [_forgetPasswordV addSubview:forgetL];
    forgetL.text = @"忘记密码";
    forgetL.font = [UIFont systemFontOfSize:19];
    forgetL.textColor = kBlackColor;
    [forgetL makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(30 * kPercent);
        make.centerX.equalTo(_forgetPasswordV
                             );
    }];
    
}

#pragma tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
//    处理按钮
    //登录
    if (tableView == _loginTableView) {
        
        if (indexPath.row == 2 || indexPath.row == 3) {
            
            ButtonCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ButtonCell"];
            
            cell.delegate = self;
            if (indexPath.row == 2) {
                cell.title = @"登      录";
                
            }else if (indexPath.row == 3){
                
                cell.title = @"注      册";
                cell.bgColor = [UIColor whiteColor];
                cell.titleColor = kBlackColor;
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
        
    }
    
    //注册
    if (tableView == _registerTableView) {
        
        if (indexPath.row == 3) {
            
            ButtonCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ButtonCell"];
            cell.title = @"注      册";
            cell.delegate = self;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
    }
    
    //忘记密码
    if (tableView == _forgetTableView) {
        
        if (indexPath.row == 3) {
            ButtonCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ButtonCell"];
            cell.title = @"确      定";
            cell.delegate = self;
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
    }
    
    //    处理输入框和验证按钮
    ImgTextBtnCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ImgTextBtnCell"];
    cell.placeHolderStr = _placeHolderArr[indexPath.row];
    cell.imgStr = _imgArr[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if ((tableView == _registerTableView || tableView == _forgetTableView) && indexPath.row == 2) {
        
        cell.isHidden = NO;
    }
     
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 40 * kPercent;
}

#pragma ButtonCellDelegate
- (void)buttonCellAction:(NSString *)buttonTitle{
    
    NSLog(@"点击的是cell上的按钮%@",buttonTitle);
    if ([buttonTitle isEqualToString:@"注      册"]) {
        
        _forgetPasswordBtn.hidden = YES;
        _loginBtn.hidden = NO;
        _agreeL.hidden = NO;
        _protocolBtn.hidden = NO;
        
        [UIView animateWithDuration:0.2 animations:^{
            
            CGRect newFrame = CGRectMake(-ScreenWidth, 0, ScreenWidth, 500);
            _contentV.frame = newFrame;
        }];
    }
}


//关闭页面
- (IBAction)closeLoginView:(UIButton *)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

//协议
- (IBAction)protocolAction:(UIButton *)sender {
    
    
}

//忘记密码
- (IBAction)forgetPassword:(UIButton *)sender {
    
    _forgetPasswordBtn.hidden = YES;
    _loginBtn.hidden = YES;
    _agreeL.hidden = YES;
    _protocolBtn.hidden = YES;
    
    [UIView animateWithDuration:0.2 animations:^{
    
        CGRect newFrame = CGRectMake(-ScreenWidth * 2, 0, ScreenWidth, 500);
        _contentV.frame = newFrame;
    }];
}

//到登录页面
- (IBAction)toLoginView:(UIButton *)sender {
    
    _forgetPasswordBtn.hidden = NO;
    _loginBtn.hidden = YES;
    _agreeL.hidden = NO;
    _protocolBtn.hidden = NO;
    
    [UIView animateWithDuration:0.2 animations:^{
        
        CGRect newFrame = CGRectMake(0, 0, ScreenWidth, 500);
        _contentV.frame = newFrame;
    }];
}









- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
