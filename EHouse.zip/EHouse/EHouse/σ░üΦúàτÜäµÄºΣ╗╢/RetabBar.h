//
//  RetabBar.h
//  花漫
//
//  Created by 黄成诺 on 16/9/14.
//  Copyright © 2016年 wangxue. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE  // 动态刷新

@interface RetabBar : UITabBar

// 加上IBInspectable就可以可视化显示相关的属性哦

/** 可视化tabBar点击时颜色 */
@property (nonatomic, strong)IBInspectable UIColor *TabBartintColor;

@end
