//
//  RetabBar.m
//  花漫
//
//  Created by 黄成诺 on 16/9/14.
//  Copyright © 2016年 wangxue. All rights reserved.
//

#import "RetabBar.h"

@implementation RetabBar
/**
 *  设置tabBar的tintColor
 *
 *  @param TabBartintColor 可视化视图传入的值
 */
- (void)setTabBartintColor:(UIColor *)TabBartintColor {
    
    self.tintColor = TabBartintColor;
}

@end
