//
//  DoubleLine.h
//  EHouse
//
//  Created by wx on 2016/12/22.
//  Copyright © 2016年 wx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DoubleLine : UIView

@end
