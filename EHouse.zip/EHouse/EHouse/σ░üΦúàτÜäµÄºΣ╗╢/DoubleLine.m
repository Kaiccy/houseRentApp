//
//  DoubleLine.m
//  EHouse
//
//  Created by wx on 2016/12/22.
//  Copyright © 2016年 wx. All rights reserved.
//

#import "DoubleLine.h"

@implementation DoubleLine

- (instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        
        UIView *line1 = [[UIView alloc] init];
        [self addSubview:line1];
        line1.backgroundColor = [UIColor blackColor];
        [line1 makeConstraints:^(MASConstraintMaker *make) {
            
            make.height.equalTo(1);
            make.left.equalTo(20);
            make.right.equalTo(20);
            make.top.equalTo(15);
            
        }];
        
        UIView *line2 = [[UIView alloc] init];
        [self addSubview:line2];
        line2.backgroundColor = [UIColor blackColor];
        [line2 makeConstraints:^(MASConstraintMaker *make) {            
            make.height.equalTo(2);
            make.left.equalTo(20);
            make.right.equalTo(20);
            make.top.equalTo(line1.bottom).equalTo(15);
        }];
    }
    
    
    return self;
}

@end
