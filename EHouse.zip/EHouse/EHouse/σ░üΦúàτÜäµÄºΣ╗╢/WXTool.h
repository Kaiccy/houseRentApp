//
//  WXTool.h
//  EHouse
//
//  Created by wx on 2017/2/7.
//  Copyright © 2017年 wx. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WXTool : NSObject


/**
 *  @function 发送一个GET请求
 *
 *  @param url     请求路径
 *  @param params  请求参数
 *  @param success 请求成功后的block回调（请求成功后需要做的操作在这个block中完成）
 *  @param failure 请求失败后的block回调（请求失败后需要做的操作在这个block中完成）
 */
+ (void)wx_GET:(NSString *)url params:(NSDictionary *)params success:(void (^)(id responseObject))success failure:(void (^)(NSError *error))failure;

/**
 *  @function 发送一个POST请求
 *
 *  @param url     请求路径
 *  @param params  请求参数
 *  @param success 请求成功后的block回调（请求成功后需要做的操作在这个block中完成）
 *  @param failure 请求失败后的block回调（请求失败后需要做的操作在这个block中完成）
 */
+ (void)wx_POST:(NSString *)url params:(NSDictionary *)params success:(void (^)(id responseObject))success failure:(void (^)(NSError *error))failure;


//GET  带有header的请求
+ (void)wx_GET:(NSString *)url params:(NSDictionary *)params header:(NSString *)header success:(void (^)(id responseObject))success failure:(void (^)(NSError *error))failure;

//POST  带有header
+ (void)wx_POST:(NSString *)url params:(NSDictionary *)params header:(NSString *)header success:(void (^)(id responseObject))success failure:(void (^)(NSError *error))failure;

//DELETE(有header)
+ (void)wx_DELETE:(NSString *)url params:(NSDictionary *)params header:(NSString *)header success:(void (^)(id responseObject))success failure:(void (^)(NSError *error))failure;

//PUT(有header)
+ (void)wx_PUT:(NSString *)url params:(NSDictionary *)params header:(NSString *)header success:(void (^)(id responseObject))success failure:(void (^)(NSError *error))failure;


@end
